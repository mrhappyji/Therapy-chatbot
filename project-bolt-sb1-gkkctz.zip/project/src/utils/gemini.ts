import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = 'AIzaSyC4jZb2AWTrQlLNACyNjCDfrybvAeqSyHc';
const genAI = new GoogleGenerativeAI(API_KEY);

const THERAPEUTIC_PROMPT = `You are an empathetic and supportive AI therapist. Your responses should be:
- Compassionate and understanding
- Non-judgmental
- Focused on active listening
- Encouraging but not dismissive
- Professional while maintaining warmth
- Careful to never provide medical advice
Always remind users that you're an AI and encourage professional help when needed.`;

export async function getChatResponse(userMessage: string): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    
    const chat = model.startChat({
      history: [
        {
          role: "user",
          parts: [THERAPEUTIC_PROMPT],
        },
        {
          role: "model",
          parts: ["I understand my role as a supportive AI companion. How can I help you today?"],
        },
      ],
    });

    const result = await chat.sendMessage(userMessage);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error getting Gemini response:', error);
    return "I apologize, but I'm having trouble processing your message right now. Please try again in a moment.";
  }
}