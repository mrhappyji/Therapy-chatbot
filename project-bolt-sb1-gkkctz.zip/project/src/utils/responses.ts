const therapeuticResponses = {
  anxiety: [
    "I hear that you're feeling anxious. Let's take a deep breath together.",
    "It's completely normal to feel overwhelmed sometimes. Would you like to talk more about what's troubling you?",
    "You're brave for sharing these feelings. Let's explore what might help you feel more grounded."
  ],
  depression: [
    "I'm here to listen without judgment. Your feelings are valid.",
    "It sounds like you're going through a difficult time. Would you like to tell me more?",
    "Remember that seeking help is a sign of strength, not weakness."
  ],
  loneliness: [
    "It's hard feeling alone. I'm here to listen whenever you need someone to talk to.",
    "Many people experience loneliness, but that doesn't make your experience any less important.",
    "Would you like to explore ways to connect with others who might understand what you're going through?"
  ],
  general: [
    "I'm here to support you. How can I help you today?",
    "Your feelings matter. Would you like to tell me more about what's on your mind?",
    "Sometimes talking about our feelings can help us understand them better. I'm listening."
  ]
};

export const getTherapeuticResponse = (input: string): string => {
  const lowercaseInput = input.toLowerCase();
  
  if (lowercaseInput.includes('anxious') || lowercaseInput.includes('worry')) {
    return therapeuticResponses.anxiety[Math.floor(Math.random() * therapeuticResponses.anxiety.length)];
  }
  
  if (lowercaseInput.includes('sad') || lowercaseInput.includes('depress')) {
    return therapeuticResponses.depression[Math.floor(Math.random() * therapeuticResponses.depression.length)];
  }
  
  if (lowercaseInput.includes('alone') || lowercaseInput.includes('lonely')) {
    return therapeuticResponses.loneliness[Math.floor(Math.random() * therapeuticResponses.loneliness.length)];
  }
  
  return therapeuticResponses.general[Math.floor(Math.random() * therapeuticResponses.general.length)];
};